# Minimal settings file placeholder

from celery import Celery
import os
from decouple import config

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "core.settings")
app = Celery("internship_project")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()

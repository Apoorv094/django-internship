# Django Internship Assignment
Refer to README section in ChatGPT for full instructions.

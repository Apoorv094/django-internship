import os
import django
from decouple import config
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "core.settings")
django.setup()

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from api.models import TelegramUser

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    username = update.message.from_user.username
    if username and not TelegramUser.objects.filter(username=username).exists():
        TelegramUser.objects.create(username=username)
        await update.message.reply_text(f"Hi {username}, you are now registered!")
    else:
        await update.message.reply_text("You are already registered or missing username.")

def run_bot():
    app = ApplicationBuilder().token(config("TELEGRAM_BOT_TOKEN")).build()
    app.add_handler(CommandHandler("start", start))
    app.run_polling()
